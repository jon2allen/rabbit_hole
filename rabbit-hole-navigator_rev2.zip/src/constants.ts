export interface Place {
  id: string;
  name: string;
  type: 'restaurant' | 'cafe';
  coordinates: [number, number]; // [lat, lng]
  rating: number;
  website?: string;
}

export interface City {
  id: string;
  name: string;
  coordinates: [number, number]; // [lat, lng]
  description: string;
  quote: string;
  places: Place[];
  isWrongTurn?: boolean;
  carrotTip?: string;
  carrotTipUrl?: string;
}

export const BUGS_CITIES: City[] = [
  {
    id: 'albuquerque',
    name: 'Albuquerque, NM',
    coordinates: [35.0844, -106.6504],
    description: 'The legendary spot where Bugs consistently misses that left turn.',
    quote: "I knew I shoulda taken that left turn at Albuquerque!",
    isWrongTurn: true,
    carrotTip: "Acre Restaurant offers vegetarian comfort food that's just doc's orders.",
    carrotTipUrl: "https://citydifferentfoodie.com/2018/09/03/acre-restaurant-vegetarian-comfort-food/",
    places: [
      { id: 'a1', name: 'Antiquity Restaurant', type: 'restaurant', coordinates: [35.0934, -106.6714], rating: 4.8, website: "https://antiquityrestaurant.com" },
      { id: 'a2', name: 'Frontier Restaurant', type: 'restaurant', coordinates: [35.0824, -106.6194], rating: 4.6, website: "https://frontierrestaurant.com" },
      { id: 'a3', name: 'Burrow Coffee', type: 'cafe', coordinates: [35.0834, -106.6494], rating: 4.5 }
    ]
  },
  {
    id: 'pismo-beach',
    name: 'Pismo Beach, CA',
    coordinates: [35.1428, -120.6413],
    description: 'The ultimate destination for all the clams you can eat.',
    quote: "Pismo Beach and all the clams we can eat!",
    carrotTip: "No need for tips here! Pismo Beach fully embraces the carrot.",
    places: [
      { id: 'p1', name: 'Ventana Grill', type: 'restaurant', coordinates: [35.1538, -120.6523], rating: 4.7, website: "https://ventanagrill.com" },
      { id: 'p2', name: 'Splash Café', type: 'cafe', coordinates: [35.1418, -120.6403], rating: 4.9, website: "https://splashcafe.com" }
    ]
  },
  {
    id: 'cucamonga',
    name: 'Cucamonga, CA',
    coordinates: [34.1064, -117.5931],
    description: 'A favorite stop along the old Route 66 area.',
    quote: "Anaheim, Azusa and Cuc-amonga!",
    carrotTip: "It's right there in front of you, doc! Check out the incredible carrot cake.",
    carrotTipUrl: "https://www.stonefiregrill.com/location/rancho-cucamonga/ca/menu/desserts/our-incredible-carrot-cake/",
    places: [
      { id: 'cu1', name: 'Stonefire Grill', type: 'restaurant', coordinates: [34.1084, -117.5951], rating: 4.5, website: "https://stonefiregrill.com" },
      { id: 'cu2', name: '+Bake Cafe', type: 'cafe', coordinates: [34.1044, -117.5911], rating: 4.7, website: "https://plusbake.com" }
    ]
  },
  {
    id: 'st-joseph',
    name: 'St. Joseph, MO',
    coordinates: [39.7675, -94.8466],
    description: "It ain't like Saint Joe!",
    quote: "I've been in plenty of tough spots, but it ain't like Saint Joe!",
    carrotTip: "Explore local farmers markets. Rumor has it Fredrick Inn has them on the menu.",
    carrotTipUrl: "https://fredrickinnsteakhouse.com/menu/",
    places: [
      { id: 'sj1', name: "Boudreaux's Louisiana Seafood", type: 'restaurant', coordinates: [39.7685, -94.8476], rating: 4.6, website: "https://boudreauxstjoe.com" },
      { id: 'sj2', name: 'Fredrick Inn Steakhouse', type: 'restaurant', coordinates: [39.7665, -94.8456], rating: 4.4, website: "https://fredrickinnsteakhouse.com" }
    ]
  },
  {
    id: 'walla-walla',
    name: 'Walla Walla, WA',
    coordinates: [46.0646, -118.3430],
    description: 'A name so nice, they named it twice.',
    quote: "Walla Walla, Washington!",
    carrotTip: "Known for onions, but carrots are rumored to be found at the farmers markets.",
    places: [
      { id: 'ww1', name: 'Saffron Mediterranean Kitchen', type: 'restaurant', coordinates: [46.0656, -118.3440], rating: 4.8, website: "https://saffronmediterraneankitchen.com" },
      { id: 'ww2', name: 'Maple Counter Cafe', type: 'cafe', coordinates: [46.0636, -118.3420], rating: 4.7, website: "https://maplecountercafe.com" }
    ]
  },
  {
    id: 'newport-news',
    name: 'Newport News, VA',
    coordinates: [37.0871, -76.4730],
    description: 'A historic port city in the Tidewater region.',
    quote: "Is this the way to Newport News?",
    places: [
      { id: 'nn1', name: "Smoke BBQ Restaurant", type: 'restaurant', coordinates: [37.0881, -76.4740], rating: 4.5, website: "https://smokenn.com" },
      { id: 'nn2', name: 'Fin Seafood', type: 'restaurant', coordinates: [37.0861, -76.4720], rating: 4.7, website: "https://finseafood.com" }
    ]
  },
  {
    id: 'coachella',
    name: 'Coachella Valley, CA',
    coordinates: [33.7222, -116.2146],
    description: 'Home of the big carrot festival, unless you end up in a bullring.',
    quote: "On my way to the big carrot festival in Coachella Valley!",
    carrotTip: "Make sure to hit the Holtville, CA carrot festival in late Jan or early Feb.",
    places: [
      { id: 'c1', name: "Sloan's", type: 'restaurant', coordinates: [33.7232, -116.2156], rating: 4.4, website: "https://sloansrestaurant.com" },
      { id: 'c2', name: 'El Mexicali Cafe II', type: 'restaurant', coordinates: [33.7212, -116.2136], rating: 4.6, website: "https://elmexicalicafe2.com" }
    ]
  },
  {
    id: 'thermopolis',
    name: 'Thermopolis, WY',
    coordinates: [43.6461, -108.2121],
    description: "Home of the world's largest mineral hot springs.",
    quote: "A lovely day for a dip in Thermopolis!",
    places: [
      { id: 'th1', name: 'P6 Station', type: 'restaurant', coordinates: [43.6471, -108.2131], rating: 4.5, website: "https://p6-station.goto-restaurants.com" },
      { id: 'th2', name: 'One Eyed Buffalo Brewing', type: 'restaurant', coordinates: [43.6451, -108.2111], rating: 4.7, website: "https://oneeyedbuffalobrewingco.com" }
    ]
  },
  {
    id: 'pittsburgh',
    name: 'Pittsburgh, PA',
    coordinates: [40.4406, -79.9959],
    description: 'Better than Transylvania, anyway.',
    quote: "Is this the way to Pittsburgh?",
    carrotTip: "Best bet, doc, is Apteka! Even if you aren't vegan, it's really tasty.",
    carrotTipUrl: "https://aptekapgh.com",
    places: [
      { id: 'pt1', name: "Pamela's Diner", type: 'restaurant', coordinates: [40.4416, -79.9969], rating: 4.6, website: "https://pamelasdiner.com" },
      { id: 'pt2', name: 'Apteka', type: 'restaurant', coordinates: [40.4396, -79.9949], rating: 4.8, website: "https://aptekapgh.com" }
    ]
  }
];
