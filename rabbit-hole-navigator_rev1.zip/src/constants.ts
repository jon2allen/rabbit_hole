export interface Place {
  id: string;
  name: string;
  type: 'restaurant' | 'cafe';
  coordinates: [number, number]; // [lat, lng]
  rating: number;
}

export interface City {
  id: string;
  name: string;
  coordinates: [number, number]; // [lat, lng]
  description: string;
  quote: string;
  places: Place[];
  isWrongTurn?: boolean;
}

export const BUGS_CITIES: City[] = [
  {
    id: 'albuquerque',
    name: 'Albuquerque',
    coordinates: [35.0844, -106.6504],
    description: 'The legendary spot where Bugs consistently misses that left turn.',
    quote: "I knew I shoulda taken that left turn at Albuquerque!",
    isWrongTurn: true,
    places: [
      { id: 'a1', name: 'Albuquerque Diner', type: 'restaurant', coordinates: [35.0854, -106.6514], rating: 4.5 },
      { id: 'a2', name: 'Burrow Coffee', type: 'cafe', coordinates: [35.0834, -106.6494], rating: 4.8 },
      { id: 'a3', name: 'The Crunchy Corner', type: 'restaurant', coordinates: [35.0864, -106.6484], rating: 4.2 }
    ]
  },
  {
    id: 'pismo-beach',
    name: 'Pismo Beach',
    coordinates: [35.1428, -120.6413],
    description: 'The ultimate destination for all the clams you can eat.',
    quote: "Pismo Beach and all the clams we can eat!",
    places: [
      { id: 'p1', name: 'Clam Central', type: 'restaurant', coordinates: [35.1438, -120.6423], rating: 4.9 },
      { id: 'p2', name: 'Seaside Sips', type: 'cafe', coordinates: [35.1418, -120.6403], rating: 4.4 },
      { id: 'p3', name: 'The Shell Shack', type: 'restaurant', coordinates: [35.1448, -120.6403], rating: 4.6 }
    ]
  },
  {
    id: 'coachella',
    name: 'Coachella Valley',
    coordinates: [33.6803, -116.1739],
    description: 'Home of the big carrot festival, unless you end up in a bullring.',
    quote: "On my way to the big carrot festival in Coachella Valley!",
    places: [
      { id: 'c1', name: 'Carrot Crunch Cafe', type: 'cafe', coordinates: [33.6813, -116.1749], rating: 4.7 },
      { id: 'c2', name: 'Festival Grille', type: 'restaurant', coordinates: [33.6793, -116.1729], rating: 4.3 }
    ]
  },
  {
    id: 'manhattan',
    name: 'Manhattan',
    coordinates: [40.7128, -74.0060],
    description: 'Where a young hare grew up on the Lower East Side.',
    quote: "A hare grows in Manhattan, doc!",
    places: [
      { id: 'm1', name: 'Lower East Latte', type: 'cafe', coordinates: [40.7138, -74.0070], rating: 4.8 },
      { id: 'm2', name: 'Bunny Deli', type: 'restaurant', coordinates: [40.7118, -74.0050], rating: 4.6 }
    ]
  },
  {
    id: 'pittsburgh',
    name: 'Pittsburgh',
    coordinates: [40.4406, -79.9959],
    description: 'Better than Transylvania, anyway.',
    quote: "Is this the way to Pittsburgh?",
    places: [
      { id: 'pt1', name: 'Bridge Brews', type: 'cafe', coordinates: [40.4416, -79.9969], rating: 4.2 },
      { id: 'pt2', name: 'Steel City Salads', type: 'restaurant', coordinates: [40.4396, -79.9949], rating: 4.5 }
    ]
  },
  {
    id: 'altoona',
    name: 'Altoona, PA',
    coordinates: [40.5187, -78.3947],
    description: 'A key stop in the Keystone State, home of the Horseshoe Curve.',
    quote: "Altoona! I hope they have some high-altitude carrots!",
    places: [
      { id: 'al1', name: 'Keystone Coffee', type: 'cafe', coordinates: [40.5197, -78.3957], rating: 4.4 },
      { id: 'al2', name: 'Railroad Diner', type: 'restaurant', coordinates: [40.5177, -78.3937], rating: 4.6 }
    ]
  },
  {
    id: 'chicago',
    name: 'Chicago, IL',
    coordinates: [41.8781, -87.6298],
    description: 'A windy city Bugs warns Yosemite Sam to wear overshoes for.',
    quote: "Don't forget your overshoes in Chicago, Sam!",
    places: [
      { id: 'chi1', name: 'Windy City Waffles', type: 'restaurant', coordinates: [41.8791, -87.6308], rating: 4.5 },
      { id: 'chi2', name: 'Deep Dish Delicates', type: 'restaurant', coordinates: [41.8771, -87.6288], rating: 4.7 }
    ]
  },
  {
    id: 'st-louis',
    name: 'St. Louis, MO',
    coordinates: [38.6270, -90.1994],
    description: 'The destination for a screwy goodbye at the Gateway Arch.',
    quote: "So long screwy, see you in St. Louie!",
    places: [
      { id: 'sl1', name: 'Archway Cafe', type: 'cafe', coordinates: [38.6280, -90.2004], rating: 4.3 },
      { id: 'sl2', name: 'Screwy BBQ', type: 'restaurant', coordinates: [38.6260, -90.1984], rating: 4.6 }
    ]
  },
  {
    id: 'las-vegas',
    name: 'Las Vegas, NV',
    coordinates: [36.1716, -115.1391],
    description: 'The bright lights Bugs was expecting before hitting Germany.',
    quote: "Las Vegas! I can almost hear the slot machines!",
    places: [
      { id: 'lv1', name: 'Jackpot Juice', type: 'cafe', coordinates: [36.1726, -115.1401], rating: 4.1 },
      { id: 'lv2', name: 'The High Roller Grille', type: 'restaurant', coordinates: [36.1706, -115.1381], rating: 4.8 }
    ]
  },
  {
    id: 'miami-beach',
    name: 'Miami Beach, FL',
    coordinates: [25.7907, -80.1300],
    description: 'A classic vacation spot for a very relaxed rabbit.',
    quote: "See you in Miami Beach!",
    places: [
      { id: 'mb1', name: 'Sunny Side Sips', type: 'cafe', coordinates: [25.7917, -80.1310], rating: 4.5 },
      { id: 'mb2', name: 'Flamingo Fare', type: 'restaurant', coordinates: [25.7897, -80.1290], rating: 4.4 }
    ]
  },
  {
    id: 'palm-springs',
    name: 'Palm Springs, CA',
    coordinates: [33.8303, -116.5453],
    description: 'A sunny resort town Bugs often tries to reach.',
    quote: "Palm Springs! Here I come!",
    places: [
      { id: 'ps1', name: 'Desert Oasis Coffee', type: 'cafe', coordinates: [33.8313, -116.5463], rating: 4.6 },
      { id: 'ps2', name: 'Cactus Grill', type: 'restaurant', coordinates: [33.8293, -116.5443], rating: 4.2 }
    ]
  },
  {
    id: 'walla-walla',
    name: 'Walla Walla, WA',
    coordinates: [46.0646, -118.3430],
    description: 'A name so nice, they named it twice.',
    quote: "Walla Walla, Washington!",
    places: [
      { id: 'ww1', name: 'Double Name Diner', type: 'restaurant', coordinates: [46.0656, -118.3440], rating: 4.8 },
      { id: 'ww2', name: 'Walla Walla Whisk', type: 'cafe', coordinates: [46.0636, -118.3420], rating: 4.5 }
    ]
  }
];
