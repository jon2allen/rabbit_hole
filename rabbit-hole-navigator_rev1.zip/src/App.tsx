import React, { useState, useEffect } from 'react';
import { MapPin, Utensils, Coffee, Navigation, ChevronLeft, ChevronRight, Rabbit, Info, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { BUGS_CITIES, City, Place } from './constants';

// --- Custom Components ---

// Component to handle map view updates
function MapController({ center, zoom }: { center: [number, number], zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom, { animate: true, duration: 1.5 });
  }, [center, zoom, map]);
  return null;
}

// Custom markers using Leaflet's divIcon
const createCityIcon = () => L.divIcon({
  html: `<div class="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-2xl border-4 border-orange-500 animate-bounce">
           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f97316" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 5.172C10 3.782 8.423 2.679 6.5 3c-1.923.321-3.5 1.818-3.5 3.208 0 1.39 1.577 2.493 3.5 2.172a3.09 3.09 0 0 0 2.441-1.859L11 9l4 3.5m-5-7.328c0 1.39 1.577 2.493 3.5 2.172 1.923-.321 3.5-1.818 3.5-3.208 0-1.39-1.577-2.493-3.5-2.172a3.09 3.09 0 0 0-2.441 1.859L11 3.5l-4-3.5M12 9c2 0 4 2 4 4s-2 4-4 4-4-2-4-4 2-4 4-4Z"/><path d="M10 20c0-1 2-2 2-2s2 1 2 2-2 2-2 2-2-1-2-2Z"/></svg>
         </div>`,
  className: '',
  iconSize: [48, 48],
  iconAnchor: [24, 48],
});

const createPlaceIcon = (type: 'restaurant' | 'cafe') => L.divIcon({
  html: `<div class="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-lg border-2 ${type === 'cafe' ? 'border-sky-500' : 'border-green-500'}">
           ${type === 'cafe' 
             ? '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0ea5e9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" x2="6" y1="2" y2="4"/><line x1="10" x2="10" y1="2" y2="4"/><line x1="14" x2="14" y1="2" y2="4"/></svg>' 
             : '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/></svg>'}
         </div>`,
  className: '',
  iconSize: [32, 32],
  iconAnchor: [16, 16],
});

export default function App() {
  const [selectedCity, setSelectedCity] = useState<City>(BUGS_CITIES[0]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isBurrowTrip, setIsBurrowTrip] = useState(false);

  const usaCenter: [number, number] = [39.8283, -98.5795];

  return (
    <div className="w-full h-screen flex flex-col bg-orange-50 font-sans text-slate-800 overflow-hidden" style={{ backgroundColor: '#FFF7ED' }}>
      
      {/* Navigation Header */}
      <nav className="h-16 flex items-center justify-between px-6 bg-white border-b-4 border-orange-200 shadow-sm z-30 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center border-2 border-white shadow-md">
            <span className="text-white font-black text-xl">🥕</span>
          </div>
          <h1 className="text-2xl font-black text-orange-600 tracking-tight italic">BugsMap!</h1>
        </div>
        
        <div className="flex-1 max-w-md mx-8">
          <div className="relative flex items-center">
            <input 
              type="text" 
              placeholder="Search for carrots or cafes..." 
              className="w-full py-2 px-5 bg-orange-100 border-2 border-orange-300 rounded-full focus:outline-none focus:ring-2 focus:ring-orange-400 text-sm font-medium"
            />
            <Search className="absolute right-4 w-4 h-4 text-orange-400" />
          </div>
        </div>

        <div className="flex items-center gap-4 text-sm font-bold">
          {isBurrowTrip ? (
            <div className="px-4 py-1 bg-orange-500 text-white rounded-full border border-orange-600 animate-pulse">
              Panning the Tunnel...
            </div>
          ) : (
            <div className="hidden md:block px-4 py-1 bg-green-100 text-green-700 rounded-full border border-green-200">
              Where next, Doc?
            </div>
          )}
          <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-orange-400 overflow-hidden">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Bugs" alt="User Profile" />
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden relative">
        
        {/* Interactive Sidebar */}
        <AnimatePresence initial={false}>
          {sidebarOpen && (
            <motion.aside 
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="bg-white border-r-2 border-orange-100 flex flex-col shadow-inner overflow-hidden shrink-0 z-20"
            >
              <div className="p-4 bg-orange-50 border-b border-orange-100">
                <h2 className="text-xs uppercase tracking-widest font-black text-orange-400">Visited Destinations</h2>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                {BUGS_CITIES.map((city) => (
                  <div 
                    key={city.id}
                    onClick={() => {
                      setSelectedCity(city);
                      setIsBurrowTrip(false);
                    }}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer group shadow-sm ${
                      !isBurrowTrip && selectedCity.id === city.id 
                      ? 'bg-orange-500 border-orange-600 text-white shadow-lg scale-[1.02]' 
                      : 'bg-white border-orange-200 hover:border-orange-500 text-slate-800'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-lg font-bold">{city.name}</span>
                      {city.isWrongTurn && (
                        <span className={`text-[8px] px-2 py-0.5 rounded-full font-black uppercase tracking-tighter ${
                          !isBurrowTrip && selectedCity.id === city.id ? 'bg-white text-orange-600' : 'bg-red-100 text-red-600'
                        }`}>
                          Wrong Turn
                        </span>
                      )}
                    </div>
                    <p className={`text-xs mb-3 ${!isBurrowTrip && selectedCity.id === city.id ? 'text-orange-100' : 'text-slate-500'}`}>
                      {city.description}
                    </p>
                    <div className="flex gap-2">
                      <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${
                        !isBurrowTrip && selectedCity.id === city.id ? 'bg-orange-600 text-white' : 'text-orange-600 bg-orange-50'
                      }`}>
                        {city.places.filter(p => p.type === 'restaurant').length} Restaurants
                      </span>
                      <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${
                        !isBurrowTrip && selectedCity.id === city.id ? 'bg-orange-600 text-white' : 'text-sky-600 bg-sky-50'
                      }`}>
                        {city.places.filter(p => p.type === 'cafe').length} Cafes
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-4 bg-slate-50 border-t border-slate-200">
                <button 
                  onClick={() => setIsBurrowTrip(true)}
                  className={`w-full py-3 font-black rounded-xl shadow-md transform active:scale-95 transition-all text-white ${
                    isBurrowTrip ? 'bg-orange-400 cursor-default' : 'bg-green-500 hover:bg-green-600'
                  }`}
                >
                  {isBurrowTrip ? 'In the Tunnel...' : 'Plan a Burrow Trip'}
                </button>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Map Area */}
        <div className="flex-1 relative bg-sky-50 overflow-hidden">
          {/* Toggle Sidebar Button */}
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="absolute top-6 left-6 z-20 w-10 h-10 bg-white rounded-xl shadow-xl border-2 border-orange-100 flex items-center justify-center hover:bg-orange-50 transition-colors"
          >
            {sidebarOpen ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          </button>

          {/* Info HUD */}
          <div className="absolute top-6 right-6 z-20 bg-white/90 backdrop-blur p-4 rounded-3xl border-2 border-white shadow-xl max-w-[220px]">
            <p className="text-[10px] font-black text-orange-600 mb-2 uppercase tracking-tighter">
              {isBurrowTrip ? 'Planning the dig' : 'Currently Exploring'}
            </p>
            <p className="text-xl font-black leading-tight text-slate-800">
              {isBurrowTrip ? 'Across the USA' : selectedCity.name}
            </p>
            {!isBurrowTrip && (
              <p className="text-[10px] text-slate-500 mt-2 italic border-t border-orange-100 pt-2 font-medium leading-relaxed">
                "{selectedCity.quote}"
              </p>
            )}
          </div>

          {/* Leaflet MapContainer */}
          <div className="w-full h-full relative">
            <MapContainer 
              center={isBurrowTrip ? usaCenter : selectedCity.coordinates} 
              zoom={isBurrowTrip ? 4 : 13} 
              className="w-full h-full"
              zoomControl={false}
              attributionControl={false}
            >
              <TileLayer
                url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
              />
              
              <MapController center={isBurrowTrip ? usaCenter : selectedCity.coordinates} zoom={isBurrowTrip ? 4 : 13} />
              
              {isBurrowTrip ? (
                // Burrow Mode: Show carrots at all locations
                BUGS_CITIES.map(city => (
                  <Marker 
                    key={city.id} 
                    position={city.coordinates} 
                    icon={L.divIcon({
                      html: `<div class="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-orange-500 hover:scale-125 transition-transform">
                              <span class="text-xl">🥕</span>
                            </div>`,
                      className: '',
                      iconSize: [40, 40],
                      iconAnchor: [20, 40],
                    })}
                    eventHandlers={{
                      click: () => {
                        setSelectedCity(city);
                        setIsBurrowTrip(false);
                      }
                    }}
                  >
                    <Popup>
                      <div className="p-1">
                        <p className="font-black text-orange-600">{city.name}</p>
                        <p className="text-[10px] text-slate-400 uppercase font-black">Click to dig here!</p>
                      </div>
                    </Popup>
                  </Marker>
                ))
              ) : (
                // Local Mode: Standard markers
                <>
                  <Marker position={selectedCity.coordinates} icon={createCityIcon()}>
                    <Popup>
                      <div className="p-2">
                        <p className="font-bold text-orange-600">Bugs is here!</p>
                        <p className="text-xs text-slate-600">"{selectedCity.quote}"</p>
                      </div>
                    </Popup>
                  </Marker>

                  {selectedCity.places.map((place) => (
                    <Marker 
                      key={place.id} 
                      position={place.coordinates} 
                      icon={createPlaceIcon(place.type)}
                    >
                      <Popup>
                        <div className="p-2 min-w-[120px]">
                          <p className="font-black text-slate-800 text-sm leading-tight">{place.name}</p>
                          <p className="text-[10px] uppercase font-black text-slate-400 mt-1">
                            {place.type === 'cafe' ? 'Bunny Brews' : 'Gourmet Greens'}
                          </p>
                          <div className="mt-2 flex gap-0.5 text-amber-400">
                            {[...Array(5)].map((_, i) => (
                              <span key={i}>{i < Math.floor(place.rating) ? '★' : '☆'}</span>
                            ))}
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                </>
              )}
            </MapContainer>
          </div>

          {/* Legend Legend */}
          <div className="absolute bottom-6 left-6 z-20 flex gap-2 pointer-events-none">
            <div className="bg-white/80 backdrop-blur px-4 py-2 rounded-2xl shadow-lg border-2 border-white flex gap-4">
               <div className="flex items-center gap-2">
                 <div className="w-3 h-3 rounded-full bg-orange-500" />
                 <span className="text-[10px] font-black uppercase text-slate-600 tracking-tighter">Bugs</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-3 h-3 rounded-full bg-green-500" />
                 <span className="text-[10px] font-black uppercase text-slate-600 tracking-tighter">Eats</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-3 h-3 rounded-full bg-sky-500" />
                 <span className="text-[10px] font-black uppercase text-slate-600 tracking-tighter">Sips</span>
               </div>
            </div>
          </div>
        </div>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #fed7aa;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #fb923c;
        }
        .leaflet-container {
          background: #f0f9ff !important;
        }
        .leaflet-popup-content-wrapper {
          border-radius: 1rem !important;
          box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1) !important;
          border: 2px solid #fff7ed !important;
        }
        .leaflet-popup-tip {
          background: white !important;
        }
      `}</style>
    </div>
  );
}
